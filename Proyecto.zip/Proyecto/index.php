<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <!-- Estilos CSS -->
    <link rel="stylesheet" type="text/css" href="./css/estilos.css">
    <link rel="stylesheet" type="text/css" href="./css/menu.css">
</head>
<body>

    <nav>
        <ul class="menu">
            <li class="logo"> 
                <a href="#"> 
                    <img src="./img/perfil.png"> 
                </a>  
            </li>
            <li> 
                <a href="modulos/estudiantes/estudiantes.php">    
                    Estudiantes  
                </a>  
            </li>
            <li> 
                <a href="modulos/materias/materias.php">    
                    Materias 
                </a>  
            </li>
        </ul>
    </nav>

    <div class="container">
        <header> 
            <h1> 
                Proyecto Final
            </h1>
        </header>
     
        <section class="section-flex">
            
            <article class="character">
                <header> <h2> Byron Cruz </h2>  </header>
                <img src="./img/avatar.png">
                <div class="info-character">
                    <p> <b> Genero: </b> Masculino </p>
                    <p> <b> Especie: </b> Humano </p>
                </div>
            </article>

            


            
        </section>

    </div>
    

    <footer>
        <p> Creado por Byron Cruz</p>
    </footer>

    <script src="./js/javascript.js"></script>

</body>
</html>