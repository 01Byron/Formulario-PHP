<?php
    session_start();
    include_once("../../config/DBConect.php");
    include_once("../../config/Config.php");    

    if(isset($_POST['codigo']))      $codigo = $_POST['codigo']; 
    if(isset($_POST['nombre']))      $nombre = $_POST['nombre'];
    if(isset($_POST['creditos']))    $creditos = $_POST['creditos'];
    if(isset($_POST['profesor']))    $profesor = $_POST['profesor'];
    

    $conexion = new Database;  
    $result = $conexion->CrearMateria($codigo,$nombre,$creditos,$profesor);

    header("Location: ".ROOT."modulos/materias/materias.php?mensaje=".$result);

?>